package homework;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Decisiontrees {

	static HashMap<String, Integer> Class1 = new HashMap<String, Integer>(); // ù��°
	static HashMap<String, Integer> Class2 = new HashMap<String, Integer>(); // �ι�°
	static HashMap<String, Integer> Class3 = new HashMap<String, Integer>(); // ����°

	static Node tree1, tree2, tree3;
	static String[] testarray1 = new String[8];
	static String[] testarray2 = new String[8];
	static String[] testarray3 = new String[8];

	public static void main(String[] args) throws IOException { // ù��°, �ι�°, ����°
																// �õ��� ���ؼ�
																// class1,
																// class2,
																// class3�� ������.
		String s;
		int count1 = 0;
		int count2 = 0;
		int count3 = 0;
		int counttest1 = 0;
		int counttest2 = 0;
		int counttest3 = 0;
		String[] dataarray1 = new String[8];
		String[] dataarray2 = new String[8];
		String[] dataarray3 = new String[8];
		int scount = 0;

		try {
			BufferedReader br = new BufferedReader(
					new FileReader("C://Users/Poweruser/Downloads/play-tennis_train.txt"));
			BufferedWriter out = new BufferedWriter(new FileWriter("C://Users/Poweruser/Downloads/out.txt"));
			while ((s = br.readLine()) != null) { // ����, outlook���� ���Ѵ�!
				String[] arr = s.split(","); // ',' is delimiter
				String classname = arr[4];
				String outlook = arr[0];
				String temperature = arr[1];
				String humidity = arr[2];
				String wind = arr[3];

				if (scount > 3) { // 0,1,2,3�� test�� ��
					dataarray1[count1] = outlook + "|" + temperature + "|" + humidity + "|" + wind + "|" + classname;

					String classoutlook = outlook + "|" + classname;

					if (!Class1.containsKey(classoutlook)) {
						Class1.put(classoutlook, 1);
					} else {
						int tempvalue = Class1.get(classoutlook);
						Class1.replace(classoutlook, tempvalue + 1);
					}
					count1 += 1;
				} else { // test data
					testarray1[counttest1] = outlook + "|" + temperature + "|" + humidity + "|" + wind + "|"
							+ classname;
					counttest1 += 1;
				}

				if ((0 <= scount && scount <= 3) || scount > 7) { // 4,5,6,7��
																	// test�� ��
					dataarray2[count2] = outlook + "|" + temperature + "|" + humidity + "|" + wind + "|" + classname;

					String classoutlook = outlook + "|" + classname;

					if (!Class2.containsKey(classoutlook)) {
						Class2.put(classoutlook, 1);
					} else {
						int tempvalue = Class2.get(classoutlook);
						Class2.replace(classoutlook, tempvalue + 1);
					}
					count2 += 1;
				} else {
					testarray2[counttest2] = outlook + "|" + temperature + "|" + humidity + "|" + wind + "|"
							+ classname;
					counttest2 += 1;
				}

				if (scount < 8) { // 8,9,10,11�� test�� ��
					dataarray3[count3] = outlook + "|" + temperature + "|" + humidity + "|" + wind + "|" + classname;

					String classoutlook = outlook + "|" + classname;

					if (!Class3.containsKey(classoutlook)) {
						Class3.put(classoutlook, 1);
					} else {
						int tempvalue = Class3.get(classoutlook);
						Class3.replace(classoutlook, tempvalue + 1);
					}
					count3 += 1;
				} else {
					testarray3[counttest3] = outlook + "|" + temperature + "|" + humidity + "|" + wind + "|"
							+ classname;
					counttest3 += 1;
				}

				scount += 1;
			}

			// test ����

			int hit1 = 0;
			int hit2 = 0;
			int hit3 = 0;

			tree1 = Findbestsplit(tree1, dataarray1, Class1, count1, "root", 0);
			System.out.println("----------------tree1");

			for (int i = 0; i < 4; i++) {
				String arr[] = testarray1[i].split("\\|");
				String outlook = arr[0];
				String temperature = arr[1];
				String humidity = arr[2];
				String wind = arr[3];
				String answer = arr[4];
				
				if (tree1.getData().equals(outlook)) { //outlook yes
					if (tree1.getLeft().getData().equals(answer)) {
						hit1 += 1;
					}
				} else { //outlook no
					if (tree1.getRight().getData().equals(temperature)) { //temperature yes
						if (tree1.getRight().getLeft().getData().equals(humidity)) { //humidity yes
							if (tree1.getRight().getLeft().getLeft().getData().equals(answer)) {
								hit1 += 1;
							}
						} else { //humidity no
							if (tree1.getRight().getLeft().getRight().getData().equals(answer)) {
								hit1 += 1;
							}
						}
					} else { //temperature no
						if (tree1.getRight().getRight().getData().equals(humidity)) { //humidity yes
 							if (tree1.getRight().getRight().getLeft().getData().equals(wind)) { //wind yes
 								if (tree1.getRight().getRight().getLeft().getLeft().getData().equals(answer)) {
 									hit1 += 1;
 								}
 							} else { //wind no
 								if (tree1.getRight().getRight().getLeft().getRight().getData().equals(answer)) {
 									hit1 += 1;
 								}
 							}
						} else {
							if (tree1.getRight().getRight().getRight().getData().equals(answer)) {
								hit1 += 1;
							}
						}
					}
				}

			}

			tree2 = Findbestsplit(tree2, dataarray2, Class2, count2, "root", 0);
			System.out.println("----------------tree2");

			for (int i = 0; i < 4; i++) {
				String arr[] = testarray2[i].split("\\|");
				String outlook = arr[0];
				String temperature = arr[1];
				String answer = arr[4];
				
				if (tree2.getData().equals(outlook)) { //outlook yes
					if (tree2.getLeft().getData().equals(temperature)) { //temperature yes
						if (tree2.getLeft().getLeft().getData().equals(answer)) {
							hit2 += 1;
						}
					} else { //temperature no
						if (tree2.getLeft().getRight().getData().equals(answer)) {
							hit2 += 1;
						}
					}
				} else { //outlook no
					if (tree2.getRight().getData().equals(answer)) {
						hit2 += 1;
					}
				}

			}

			tree3 = Findbestsplit(tree3, dataarray3, Class3, count3, "root", 0);
			System.out.println("----------------tree3");

			for (int i = 0; i < 4; i++) {
				String arr[] = testarray3[i].split("\\|");
				String outlook = arr[0];
				String temperature = arr[1];
				String humidity = arr[2];
				String wind = arr[3];
				String answer = arr[4];
				
				if (tree3.getData().equals(outlook)) { //outlook yes
					if (tree3.getLeft().getData().equals(temperature)) { //temperature yes
						if (tree3.getLeft().getLeft().getData().equals(answer)) {
							hit3 += 1;
						}
					} else { //temperature no
						if (tree3.getLeft().getRight().getData().equals(answer)) {
							hit3 += 1;
						}
					}
				} else { //outlook no
					if (tree3.getRight().getData().equals(temperature)) { //temperature yes
						if (tree3.getRight().getLeft().getData().equals(humidity)) { //humidity yes
							if (tree3.getRight().getLeft().getLeft().getData().equals(wind)) { //wind yes
								if (tree3.getRight().getLeft().getLeft().getLeft().getData().equals(answer)) {
									hit3 += 1;
								}
							} else { //wind no
								if (tree3.getRight().getLeft().getLeft().getRight().getData().equals(answer)) {
									hit3 += 1;
								}
							}
						} else { //humidity no
							if (tree3.getRight().getLeft().getRight().getData().equals(answer)) {
								hit3 += 1;
							}
						}
					} else { //temperature no
						if (tree3.getRight().getRight().getData().equals(answer)) {
							hit3 += 1;
						}
					}
				}
			}
			
			int hit4 = hit1 + hit2 + hit3;
			
			BigDecimal test = new BigDecimal("4");
			BigDecimal alltest = new BigDecimal("12");
			BigDecimal hi1 = new BigDecimal(hit1);
			hi1 = hi1.divide(test, 3, BigDecimal.ROUND_CEILING);
			BigDecimal hi2 = new BigDecimal(hit2);
			hi2 = hi2.divide(test, 3, BigDecimal.ROUND_CEILING);
			BigDecimal hi3 = new BigDecimal(hit3);
			hi3 = hi3.divide(test, 3, BigDecimal.ROUND_CEILING);
			BigDecimal hi4 = new BigDecimal(hit4);
			hi4 = hi4.divide(alltest, 3, BigDecimal.ROUND_CEILING);
			
			out.write("1��° �ٺ��� 4��° �ٱ��� test data, �������� training data�� ���� ��");
			out.newLine();
			out.write("Precision 1:" + hi1.toString());
			out.newLine();
			out.write("5��° �ٺ��� 8��° �ٱ��� test data, �������� training data�� ���� ��");
			out.newLine();
			out.write("Precision 2:" + hi2.toString());
			out.newLine();
			out.write("9��° �ٺ��� 12��° �ٱ��� test data, �������� training data�� ���� ��");
			out.newLine();
			out.write("Precision 3:" + hi3.toString());
			out.newLine();
			out.write("�� Precision:" + hi4.toString());
			out.newLine();
			

			out.close();
			br.close();
		} catch (

		FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Node Findbestsplit(Node tree, String[] data, HashMap<String, Integer> classes, int allnumber,
			String side, int step) {

		HashMap<String, Integer> tempclassyes = new HashMap<String, Integer>(); // yes
		HashMap<String, Integer> tempclassno = new HashMap<String, Integer>(); // no
		HashMap<String, Integer> tempclass = new HashMap<String, Integer>();
		int tempall = 0;

		Set<String> keys = classes.keySet(); // ���� �����ͼ��� �����Ѵ�! <Sunny|Yes, 2.0>

		Iterator<String> itr = keys.iterator();

		while (itr.hasNext()) {
			String keyss = itr.next();

			if (keyss != null) {
				String[] arr = keyss.split("\\|"); // ',' is delimiter.

				int valuess = classes.get(keyss); // # of yes or no

				if (arr[1].equals("Yes")) {
					tempclassyes.put(arr[0], valuess);
				} else if (arr[1].equals("No")) { // no
					tempclassno.put(arr[0], valuess);
				}

				if (!tempclass.containsKey(arr[0])) {
					tempclass.put(arr[0], valuess);
				} else {
					int tempvalue = tempclass.get(arr[0]);
					tempclass.replace(arr[0], tempvalue + valuess);
				}
			}
		}

		BigDecimal bestvalue = new BigDecimal("0");
		String bestnode = null;
		int tempcount = 0;

		Set<String> key = tempclass.keySet(); // ���� �����ͼ��� �����Ѵ�! <Sunny|Yes,
												// 2.0> �̷� �����̹Ƿ�.
		Iterator<String> it = key.iterator();

		while (it.hasNext()) {
			String keyss = it.next(); // ù��° ��Ʈ������ ���� ����صд�.

			int valuesyes = 0;
			int valuesno = 0;

			if (tempclassyes.containsKey(keyss)) {
				valuesyes = tempclassyes.get(keyss); // # of yes
			}

			if (tempclassno.containsKey(keyss)) {
				valuesno = tempclassno.get(keyss); // # of no
			}

			tempall = tempclass.get(keyss); // �ش� ��Ʈ���� �� ����!

			BigDecimal temp = Bigcalculate(valuesyes, valuesno, tempall, allnumber); // �ش�
																						// ��Ʈ����
																						// ��Ʈ����

			Set<String> key1 = tempclass.keySet(); // �ش� ��Ʈ���� ������ ������ ���� ���ϱ� ����
			Iterator<String> it1 = key1.iterator();
			int valuesyes1 = 0; // # of yes
			int valuesno1 = 0; // # of no
			int tempall1 = 0; // ������ ��Ʈ���� �� ����!
			int endsign = 0;

			while (it1.hasNext()) {
				String keyss1 = it1.next();
				if (!keyss1.equals(keyss)) {
					endsign = 1;
					if (tempclassyes.containsKey(keyss1)) {
						valuesyes1 += tempclassyes.get(keyss1);
					}

					if (tempclassno.containsKey(keyss1)) {
						valuesno1 += tempclassno.get(keyss1);
					}
					tempall1 += tempclass.get(keyss1);
				}
			}

			BigDecimal tempremain = new BigDecimal("0");

			if (endsign == 1) { // ������ ��Ʈ������ ���� ��쿡�� ��Ʈ���� ������
				tempremain = Bigcalculate(valuesyes1, valuesno1, tempall1, allnumber); // ������
																						// ��Ʈ����
																						// ��Ʈ����
																						// //
																						// ��Ʈ����
			}

			temp = temp.add(tempremain); // �ش� ��Ʈ���� information gain

			if (tempcount == 0) { // ù��° �ܰ�� �ϴ� best�� �ο�
				bestnode = keyss;
				bestvalue = temp;
			} else {
				if (temp.compareTo(bestvalue) == 1) { // temp���� bestvalue���� ũ��
					bestnode = keyss;
					bestvalue = temp;
				}
			}

			tempcount += 1;

		}

		if (side.equals("root")) {
			tree = new Node(bestnode);
		} else if (side.equals("left")) {
			Node children = new Node(bestnode);
			tree.setLeft(children);
			tree = children;
		} else if (side.equals("right")) {
			Node children = new Node(bestnode);
			tree.setRight(children);
			tree = children;
		}

		HashMap<String, Integer> outclassleft = new HashMap<String, Integer>();
		HashMap<String, Integer> outclassright = new HashMap<String, Integer>();

		int tempyesleft = 0;
		int tempnoleft = 0;
		int tempyesright = 0;
		int tempnoright = 0;

		// ���� bestnode�� �������� �����͸� ������.
		String[] dataleft = new String[allnumber];
		int lefttemp = 0;
		String[] dataright = new String[allnumber];
		int righttemp = 0;

		for (int i = 0; i < data.length; i++) { // ���� �������� ���̿� ����..
			if (data[i] != null) {
				String[] arr = data[i].split("\\|");

				String classname = arr[4];
				String temperature = arr[1];
				String humidity = arr[2];
				String wind = arr[3];
				String classification = null;

				if (step == 0) { // outlook�� ������ ��, ���� temperature�� ���� ����!
					classification = temperature + "|" + classname;
				} else if (step == 1) { // temperature�� ������ ��, ���� humidity�� ����
										// ����!
					classification = humidity + "|" + classname;
				} else if (step == 2) { // humidity�� ������ ��, ���� wind�� ���� ����!
					classification = wind + "|" + classname;
				} 

				if (classification != null) {
					if (data[i].contains(bestnode)) { // data�� bestnode���� ������
														// �ִٸ�?

						if (classname.equals("Yes")) {
							tempyesleft += 1;
						} else {
							tempnoleft += 1;
						}

						if (!outclassleft.containsKey(classification)) {
							outclassleft.put(classification, 1);
						} else {
							int tempvalue = outclassleft.get(classification);
							outclassleft.replace(classification, tempvalue + 1);
						}

						dataleft[lefttemp] = data[i]; // "�ִ�"��(����)���� �̵���Ų��.
						lefttemp += 1;
					} else { // data�� bestnode���� ������ ���� �ʴٸ�?

						if (classname.equals("Yes")) {
							tempyesright += 1;
						} else {
							tempnoright += 1;
						}

						if (!outclassright.containsKey(classification)) {
							outclassright.put(classification, 1);
						} else {
							int tempvalue = outclassright.get(classification);
							outclassright.replace(classification, tempvalue + 1);
						}

						dataright[righttemp] = data[i]; // "����"�� (������)���� �̵���Ų��.
						righttemp += 1;
					}
				} 
			} else {
				break;
			}
		}

		step += 1;

		// leaf node ���並 Ȯ���Ѵ�.

		if (tempyesleft == lefttemp || tempyesright == righttemp) {
			if (tempyesleft == lefttemp && tempyesright != righttemp && tempnoright != righttemp) {
				Node leaf = new Node("Yes");
				tree.setLeft(leaf);

				Findbestsplit(tree, dataright, outclassright, righttemp, "right", step);
			} else if (tempyesright == righttemp && tempyesleft != lefttemp && tempnoleft != lefttemp) {
				Node leaf = new Node("Yes");
				tree.setRight(leaf);

				Findbestsplit(tree, dataleft, outclassleft, lefttemp, "left", step);
			} else if (tempyesleft == lefttemp && tempnoright == righttemp) {
				Node leaf = new Node("Yes");
				tree.setLeft(leaf);
				Node leaf2 = new Node("No");
				tree.setRight(leaf2);
			} else if (tempyesright == righttemp && tempnoleft == lefttemp) {
				Node leaf = new Node("Yes");
				tree.setRight(leaf);
				Node leaf2 = new Node("No");
				tree.setLeft(leaf2);
			} else {
				Node leaf = new Node("Yes");
				tree.setRight(leaf);
				Node leaf2 = new Node("Yes");
				tree.setLeft(leaf2);
			}

		} else if (tempnoleft == lefttemp && tempnoright == righttemp) {
			Node leaf = new Node("No");
			tree.setRight(leaf);
			Node leaf2 = new Node("No");
			tree.setLeft(leaf2);
		} else { // �� �ܴ� �� �� ��� ȣ��
			Findbestsplit(tree, dataleft, outclassleft, lefttemp, "left", step);
			Findbestsplit(tree, dataright, outclassright, righttemp, "right", step);
		}

		return tree;

	}

	public static BigDecimal Bigcalculate(int yes, int no, int all, int allnumber) {
		BigDecimal bigvalueyes = new BigDecimal(yes); //
		BigDecimal bigvalueno = new BigDecimal(no);
		BigDecimal bigtempall = new BigDecimal(all);
		BigDecimal bigallno = new BigDecimal(allnumber);
		BigDecimal minusform = new BigDecimal("-1");
		BigDecimal logvalueall = new BigDecimal(Math.log(all));

		BigDecimal logvalueyes;
		BigDecimal logvalueno;

		if (yes != 0) {
			logvalueyes = new BigDecimal(Math.log(yes));
		} else {
			logvalueyes = new BigDecimal("0");
		}

		if (no != 0) {
			logvalueno = new BigDecimal(Math.log(no));
		} else {
			logvalueno = new BigDecimal("0");
		}

		BigDecimal caltemp1 = minusform.multiply(bigtempall.divide(bigallno, 3, BigDecimal.ROUND_CEILING));
		BigDecimal caltemp2 = minusform.multiply(bigvalueyes.divide(bigtempall, 3, BigDecimal.ROUND_CEILING))
				.multiply(logvalueyes.subtract(logvalueall));
		BigDecimal caltemp3 = minusform.multiply(bigvalueno.divide(bigtempall, 3, BigDecimal.ROUND_CEILING))
				.multiply(logvalueno.subtract(logvalueall));
		BigDecimal lastcal = caltemp1.multiply(caltemp2.add(caltemp3));

		return lastcal;
	}

}
